﻿namespace FunCraft.Network.Commands
{
    using Connections;
    using System.Buffers;
    using System.Text;

    public sealed class HelpCommand(CommandDispatcher dispatcher) : ICommand
    {
        public ReadOnlySpan<byte> Name => "help"u8;
        public ReadOnlySpan<byte> Description => "Lists all available commands."u8;

        public async Task ExecuteAsync(ReadOnlyMemory<byte> args, Func<ReadOnlySpan<byte>, Task> respond,
            IPacketSender sender, CancellationToken ct)
        {
            await respond("§6--- Available Commands ---"u8);
            foreach (var cmd in dispatcher.All)
                await respond(GenerateHelpString(cmd));
        }

        private static ReadOnlySpan<byte> GenerateHelpString(ICommand cmd)
        {
            var buffer = ArrayPool<byte>.Shared.Rent(1024);
            try
            {
                var span = buffer.AsSpan();
                var pos = 0;

                var written = Encoding.UTF8.GetBytes("§e/", span[pos..]);
                pos += written;

                cmd.Name.CopyTo(span[pos..]);
                pos += cmd.Name.Length;

                written = Encoding.UTF8.GetBytes(" §7— ", span[pos..]);
                pos += written;

                cmd.Description.CopyTo(span[pos..]);
                pos += cmd.Description.Length;

                return span[..pos];
            }
            finally
            {
                ArrayPool<byte>.Shared.Return(buffer);
            }
        }
    }
}