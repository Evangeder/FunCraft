﻿namespace FunCraft.Network.Commands
{
    using Connections;

    public interface ICommand
    {
        ReadOnlySpan<byte> Name { get; }
        ReadOnlySpan<byte> Description { get; }

        /// <summary>
        /// Execute the command.
        /// <paramref name="respond"/> sends a chat message back to the caller.
        /// <paramref name="sender"/> allows sending arbitrary packets to the caller.
        /// </summary>
        Task ExecuteAsync(ReadOnlyMemory<byte> args, Func<ReadOnlySpan<byte>, Task> respond, IPacketSender sender, CancellationToken ct);
    }
}